/**
 * Single-column mobile shell, rendered by AppFrame at or below MOBILE_BREAKPOINT.
 * The conversation fills the viewport below a slim control bar; the sidebar and
 * rightbar slots render in always-mounted fixed drawers that slide in over the
 * conversation (side content stays mounted and keeps state — mirroring the
 * desktop never-unmount behavior). Drawer open state reuses the layout store:
 * the sidebar drawer tracks `narrowExpanded` (below the breakpoint
 * `toggleSidebar` flips it — the hamburger semantics) and the rightbar drawer
 * tracks `rightbarShown`. The shell-overlay slot renders above the control bar
 * but below the drawers.
 */
import type { AppFrameProps } from './AppFrame.ts';
/** Full composed props: the frame shares the mobile shell needs, plus the
 *  rendered width and the product title (browser-title projection). */
export type MobileFrameProps = Pick<AppFrameProps, 'useStore' | 'useSessions' | 'usePanelInfo' | 'actions' | 'renderSlot'> & {
    /** Rendered frame width in px; drawers size off it. */
    viewport: number;
    /** Build-configured or localized product title. */
    productTitle: string;
};
/**
 * Render the mobile single-column shell.
 * @param props - frame shares plus the viewport width and the product title.
 * @returns the mobile element tree (title projection, top bar, conversation, two drawers, overlay).
 */
export declare function MobileFrame({ useStore, usePanelInfo, useSessions, actions, renderSlot, viewport, productTitle, }: MobileFrameProps): import("react").JSX.Element;
//# sourceMappingURL=MobileFrame.d.ts.map
